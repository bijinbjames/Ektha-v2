<!DOCTYPE html>
<html lang="en">
  <!----------------------------------------head include---------------------------------------------->
<?php include("./assets/components/head.php")?>
<!----------------------------------------head include End------------------------------------------>
<body id="top">
  
 <!----------------------------------------search include start-------------------------------------------->
 <?php include("./assets/components/search.php")?>
 <!----------------------------------------search include end----------------------------------------->
 <main>
    <article>
<!----------------------------------------hero start------------------------------------------------->

      <section class="section hero" id="home" aria-label="home">
        <div class="row">

          <div class="hero-content text-centre">

         

            <h1 class="h1 hero-title" data-heading="Coming Soon...">
             <span class="span" >Coming Soon...</span>

            </h1>
			
          

        </div>
      </section>
	  
<!----------------------------------------hero END-------------------------------------------->




<!---------------------------------------barnds start
   
   

----------------------------------------------------------------------------------------------->

<!----------------------------------------------date morph animation start --------------------------->

<!----------------------------------------------date morph animation end --------------------------->




<!------------------------------------------section 1 start------------------------------------->

<!------------------------------------------section 1 END------------------------------------->



<!----------------------------------------footer include start ---------------------------------------------->
  <?php include("./assets/components/footer.php")?>
<!----------------------------------------footer include End------------------------------------------>
  <a href="#top" class="back-top-btn" aria-label="back to top" data-back-top-btn>
    <ion-icon name="caret-up"></ion-icon>
  </a>


  <script src="./assets/js/script.js" defer></script>

  <!-- 
    - ionicon link
  -->
  <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
  <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>

</body>

</html>