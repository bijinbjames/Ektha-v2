<div class="search-container" data-search-box>

<div class="input-wrapper">
  <input type="search" name="search" aria-label="search" placeholder="Search here..." class="search-field">

  <button class="search-submit" aria-label="submit search" data-search-toggler>
    <ion-icon name="search-outline"></ion-icon>
  </button>

  <button class="search-close" aria-label="close search" data-search-toggler></button>
</div>

</div>
